E:/Project/NFS\ Carbon\ Switch/nfsc-nx/src/recompiled/codegen.build.stamp: \
  E:/Project/NFS\ Carbon\ Switch/nfsc-nx/extracted_game/default.xex \
  E:/Project/NFS\ Carbon\ Switch/nfsc-nx/nfsc_manifest.toml \
  E:/Project/NFS\ Carbon\ Switch/nfsc-nx/nfsc_overrides.toml
